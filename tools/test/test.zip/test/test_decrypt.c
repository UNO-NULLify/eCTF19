//
// Created by artificial on 2/24/19.
//
#include "aes.h"
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>


int main(int argc, char *argv[]) {
    struct AES_ctx ctx;
    char *key = "TSeLsIHteueb8cg8vrKhirQpLZ81XDQZ";
    char *nonce = "UtkDDx4E";
    FILE *fp;
    char file_name[] = "/home/artificial/docs/projects/school/eCTF19/tools/files/generated/games/2048-v1.1";
    uint32_t game_size;
    uint8_t *game_buffer;

    fp = fopen(file_name, "r");
    fseek(fp, 0, SEEK_END);
    game_size = ftell(fp);
    fseek(fp, 0, SEEK_SET);

    printf("Here is your key, %s\n", key);
    printf("Here is your nonce, %s\n", nonce);

    game_buffer = (uint8_t*)malloc((size_t) (game_size + 1));

    fp = fopen(file_name, "r");
    fread(game_buffer, game_size, 1, fp);
    fclose(fp);

    printf("Read file.\n");

    // Decrypt the game
    // What is the counter?
    AES_init_ctx_iv(&ctx, (uint8_t*) key, (uint8_t*) nonce);
    AES_CTR_xcrypt_buffer(&ctx, (uint8_t *) game_buffer, sizeof(game_buffer));

    fp = fopen(file_name, "wb");
    fwrite(game_buffer, game_size, 1, fp);
    fclose(fp);

    printf("Decrypted file.\n");

    return 0;
}